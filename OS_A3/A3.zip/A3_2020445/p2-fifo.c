#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
struct data
{
    int index;
    char string[50];
};
int main()
{
    int fd1;
struct data recieve;
    // FIFO file path
    char * myfifo = "fifo";

    // Creating the named file(FIFO)
    // mkfifo(<pathname>,<permission>)
    mkfifo(myfifo, 0666);
    //int j=0;
    while(1)
    {
        fd1 = open(myfifo,O_RDONLY);
        for(int j=0;j<5;j++)
        {
            read(fd1, &recieve, sizeof(recieve));
            printf("Index: %d  String: %s\n", recieve.index,recieve.string);
            
        }
        printf("5 elemtns reciebed \n");
        // First open in read only and read
        // fd1 = open(myfifo,O_RDONLY);
        // read(fd1, str1, 80);

        // Print the read string and close
        //printf("User1: %s\n", str1);
        close(fd1);

        // Now open in write mode and write
        // string taken from user.
        fd1 = open(myfifo,O_WRONLY);
        write(fd1, &recieve.index, sizeof(int));
        close(fd1);
        if(recieve.index==49)
        {
            break;
        }
    }
}