Changing the vrumtime of a process in q1 to change its priority to make it less likely to be selected by the scheduler is as follows:

the update_curr function in fair.c inside kernel/sched is the function that changes the vrumtime after execution of a process, we increase this value directly to lower the priority
To check which process's vruntime has to be increased we need a flag to check whether it is the correct process or not, the flag itself is set by comparing the pid of all
processes running with the pid specified by the user. 

Since this flag needs to be set individually for a process that means we need to create a new variable for this inside the general task structure which the schedule entity can then access
This is done inside sched.h of the include/linux directory where variable declarations in a task structure are declared. Now this value has to be initialized whenever a process begins which in our case 
we do inside the __sched_fork function inside core.c in kernel/sched where according to the documentation it was stated that this function initialises the values whenver a new process is forked.
We set our flag =0 here.

Now onto the SysCall that we define that the user can use , we use for_each_process which can give us all the processes currently executing, we then get the pid's of these processes and compare 
it to the one that the user gave , if it is a match we set the flag that we defined in the task_struct for that process.

Now once that flag has been set we are again back to the fair.c program where the vruntime in update_curr is modified, if the flag>0 then we increase the vruntime on top of whatever the system has already
calculated using calc_delta_fair and we print out the timestamp as well as the pid of this process. To my understanding the timestamp here will be exec_start because that stores when the process
last began execution.

Sources referred to are StackOverflow and The book on Linux Kernel Programming given on the classroom page for the assignment.

the patchfile was made on linux-5.14.9 .


