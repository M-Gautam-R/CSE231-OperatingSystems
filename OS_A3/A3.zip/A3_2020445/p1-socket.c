#define SOCKET_NAME "11.socket"
     
       #include <errno.h>
       #include <stdio.h>
       #include <stdlib.h>
       #include <string.h>
       #include <sys/socket.h>
       #include <sys/un.h>
       #include <unistd.h>
     
struct data
{
    int index;
    char string[50];
};

int main(int argc, char *argv[])
       {
           int start=0;
           int end=5;
           int recieved_index;

         char *arr[55]={"String 1","String 2","String 3","String 4","String 5","String 6","String 7","String 8","String 9",
                    "String 10","String 11","String 12","String 13","String 14","String 15","String 16","String 17","String 18","String 19",
                    "String 20","String 21","String 22","String 23","String 24","String 25","String 26","String 27","String 28","String 29","String 30"
                    "String 31","String 32","String 33","String 34","String 35","String 36","String 37","String 38","String 39","String 40","String 41","String 42"
                    "String 43","String 44","String 45","String 46","String 47","String 48","String 49","String 50","String 51","String 52"};
     
        //    if (ret == -1) {
        //        fprintf(stderr, "The server is down.\n");
        //        exit(EXIT_FAILURE);
        //    }
    while(1)
    {      struct data send;
           struct sockaddr_un addr;
           int ret;
           int data_socket;
           

          

           data_socket = socket(AF_UNIX, SOCK_SEQPACKET, 0);
           if (data_socket == -1) {
               perror("socket");
               exit(EXIT_FAILURE);
           }

           memset(&addr, 0, sizeof(addr));

           

           addr.sun_family = AF_UNIX;
           strncpy(addr.sun_path, SOCKET_NAME, sizeof(addr.sun_path) - 1);

           ret = connect(data_socket, (const struct sockaddr *) &addr,sizeof(addr));
                   if (ret == -1) {
               fprintf(stderr, "The server is down.\n");
               exit(EXIT_FAILURE);
           }
    
      for (int i = start; i < end; i++) 
            {
                send.index=i;
                strcpy(send.string,arr[i]);
                //printf("1\n");
               ret = write(data_socket, &send,sizeof(send));
                
               
               if (ret == -1) {
                   perror("write");
                   break;
               }
           }
           start=start+5;
           end=end+ 5;
      

        ret = read(data_socket, &recieved_index, sizeof(int));
           if (ret == -1) {
               perror("read");
               exit(EXIT_FAILURE);
           }
           
           printf("Result = %d\n", recieved_index);
          // printf("2\n");
        if(recieved_index==49)
        {
            break;
        }
        close(data_socket);
    }
   
    }