#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

struct data
{
    int index;
    char string[50];
};
int main()
{
    int fd;
    int recieved_index;
    //printf("gsdgsegesg");
    char *arr[55]={"String 1","String 2","String 3","String 4","String 5","String 6","String 7","String 8","String 9",
                    "String 10","String 11","String 12","String 13","String 14","String 15","String 16","String 17","String 18","String 19",
                    "String 20","String 21","String 22","String 23","String 24","String 25","String 26","String 27","String 28","String 29","String 30"
                    "String 31","String 32","String 33","String 34","String 35","String 36","String 37","String 38","String 39","String 40","String 41","String 42"
                    "String 43","String 44","String 45","String 46","String 47","String 48","String 49","String 50","String 51","String 52"};
    
    char * myfifo = "fifo";
    struct data send;
   
    mkfifo(myfifo, 0666);
    int control=0;
    int start=0;
    int end=5;
    
    while(1)
    {
        // Open FIFO for write only
        fd = open(myfifo, O_WRONLY);

        for(int i=start;i<end;i++)
        {
            send.index=i;
            strcpy(send.string,arr[i]);
            write(fd, &send,sizeof(send));     
        }
        start=start+5;
        end=end+5;
        
       
        close(fd);

       
        fd = open(myfifo, O_RDONLY);

        
        read(fd, &recieved_index, sizeof(int));

        
        printf("Recieved index: %d\n", recieved_index);
        close(fd);
        if(recieved_index==49)
        {
            break;
        }
    }
    return 0;
}