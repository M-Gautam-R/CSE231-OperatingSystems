#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

// structure for message queue
struct mesg_buffer {
    long mesg_type;
    int index;
    char mesg_text[100];
} message;
  
int main()
{
    key_t key;
    int start=0;
    int end=5;
    int msgid;
    int recieved_index;
    //printf("gsdgsegesg");
    char *arr[55]={"String 1","String 2","String 3","String 4","String 5","String 6","String 7","String 8","String 9",
                    "String 10","String 11","String 12","String 13","String 14","String 15","String 16","String 17","String 18","String 19",
                    "String 20","String 21","String 22","String 23","String 24","String 25","String 26","String 27","String 28","String 29","String 30"
                    "String 31","String 32","String 33","String 34","String 35","String 36","String 37","String 38","String 39","String 40","String 41","String 42"
                    "String 43","String 44","String 45","String 46","String 47","String 48","String 49","String 50","String 51","String 52"};
    // ftok to generate unique key
    key = 2;
  
    // msgget creates a message queue
    // and returns identifier
    msgid = msgget(key, 0666 | IPC_CREAT);
    message.mesg_type = 1;

        for(int i=0;i<50;i++)
        {
            message.index=i;
            strcpy(message.mesg_text,arr[i]);
            msgsnd(msgid, &message, sizeof(message), 0);
            //printf("sent  %d\n" , i);

             msgrcv(msgid, &message, sizeof(message), 1, 0);
             if((message.index+1)%5==0)
             {
                  printf("index reieved is %d \n",message.index);
       
             }
            
            //sleep(2);
        }
        start=start+5;
        end=end+5;
        //sleep(1);
        // if(message.index==49)
        //     {
        //         break;
        //     }

   
  
    // msgsnd to send message
    
  
    // display the message
    //printf("Data send is : %s \n", message.mesg_text);
  
    return 0;
}