#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

  
// structure for message queue
struct mesg_buffer {
    long mesg_type;
    int index;
    char mesg_text[100];
} message;
  
int main()
{
    key_t key;
    int msgid;
  
    // ftok to generate unique key
    key = 2;
  
    // msgget creates a message queue
    // and returns identifier
    msgid = msgget(key, 0666 | IPC_CREAT);
    sleep(2);
    
        for (int j=0;j<50;j++)
         {
            msgrcv(msgid, &message, sizeof(message), 1, 0);
            printf("String is : %s  Index is %d\n", message.mesg_text,message.index);
            msgsnd(msgid, &message, sizeof(message), 0);
            if((message.index+1)%5==0)
             {
                 printf("5 elemtns reciebed \n");
        
             }
             if (message.index==49)
             {
                 break;
             }

        }
   
        //sleep(1);
    // if(message.index==49)
    //     {
    //         break;
    //     }

    // msgrcv to receive message
    
    // display the message
    
    
    // to destroy the message queue
    msgctl(msgid, IPC_RMID, NULL);
  
    return 0;
}