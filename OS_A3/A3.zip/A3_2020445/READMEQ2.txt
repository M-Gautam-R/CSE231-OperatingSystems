Disclaimer: All the programs were ran on linux kernel version 5.15.7 on VMWare inside Visual Studio Code via ssh\

FIFO:

The fifo program has the strings hardcoded and we send 5 strings starting from index 0 at a time, for p1-fifo we open the fifo in write only mode and send the strings
p2-fifo is opened first in read only mode then, after this exchange is done we open fifo in p1 in read only mode and p2 in write only mode , this lets us send the highest index 
fron p2 to p1. Both the string and index were passed via a struct. The resources referred to were the man pages and GFG and stack overflow.

UNIX SOCKET:

The unix socket program is quite similar to the fifo one where p1-socket acts as the client and p2-socket is the server. The server creates a socket , binds it to the socket name 
and then sets up the server to await connections via the listen sys call. From here the server recieves a struct from the client which is sent from the client via the write sys call.

We use the AF_UNIX family of sockets here and the resources refferd to were the man page for unix sockets and stackoverflow.

Message Queue:

Again the program is quite similar to fifo. We create a message queue along with the key and msgid and message_buffer required, we add another parameter of index to the struct here
we use the msgsnd and msgrcv sys calls to send the structs back and forth. We add a sleep before the for loop in p2-msg to ensure that the 2 message queues are in sync 

To run all these programs, the corresponding pairs have to be run in 2 terminals side by side with the "p2" file being executed first.
