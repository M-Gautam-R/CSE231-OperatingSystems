The program creates a new System Call using copy_to_user and copy_from user , the documentation for which was referred to from the man pages on the internet.
The diff patches have been provided for the kernel as well as the sys table in the systable_64.
The system call has been defined to take in 2 arrays of fixed size of 2x2 which has been hardcoded

the test.c program has hardcoded values for the array a, and we are printing out array b which was empty at the start

The program for printing an array is the standard double loop for a 2d matrix
The definition for the System call is the usual usage of a buffer to store the value of source variable and then the buffer sends it to destination variable.