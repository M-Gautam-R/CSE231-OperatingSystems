#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#define kernel_2d_memcpy 448

int main(int argc, char **argv)
{
  float b[2][2];
  float a[2][2]={{5.0, 10.0},{15.0, 20.0}};
  int res = syscall(kernel_2d_memcpy, a, b);
  printf("System call returned %d.\n", res);
  for(int i = 0; i<2; i++)
  {
      for(int j = 0;j<2;j++){
          printf("%f ", b[i][j]);
      }
      printf("\n");
  }
  return 0;
}


// SYSCALL_DEFINE2 (kernel_2d_memcpy, float **, a1, float **, a2)
// {
// 	float a3 [2][2] ;
// 	int i = copy_from_user(a3,a1,sizeof(a3));
// 	int j = copy_to_user(a2,a3,sizeof(a3));
// 	if (i<0)
// 	{
// 		return -EFAULT;
// 	}
// 	if (j<0)
// 	{
// 		return -EFAULT;
// 	}
// 	return 3;
// }