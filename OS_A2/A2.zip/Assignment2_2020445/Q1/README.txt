The program's flow is as follows : the main program S1 forks a process which in this case is the S1 process that declares a SIGTERM handler 
and we use sigaction here because we want to recieve some value from whatever process sends the SIGTERM signal.
The Syntax for sigaction has been referenced from the internet(stackexchange).

Now SR and ST have been created from the second fork call where the child process from here is SR and the parent
process leftover is used as ST.

Also exec wants a char * arg and pid_t is not that and so we convert it using sprintf

Now in E1,rdrand is the function that generates the random number in question and again the syntax for the inline assembly 
has been taken from stackexchange and other enthusiast linux websites.

The PrintE1 is the handler function here and we declare a union sigval because that is the datatype that sigqueue accepts
In the main function we declare a timer using the itimerval struct and setitimer, the syntax has again been referenced from 
stackoverflow

Now in E2, the rdtsc function has the return type of unsigned long long because it is a 64 bit number that is stored in the eax and edx registers ie the high 32 bits and low 32 bits are stores in these 
registers and then they are combined to give our random number.There was an attempt at converting the number into a readable form which didn't work

The PrintE2 is the handler for ST and the logic for the handling as well as the timer is the same as in E1. 