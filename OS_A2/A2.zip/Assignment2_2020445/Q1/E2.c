
#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
pid_t pid1;
unsigned long long rdtsc()
{
    int high32;
    int low32;
	asm volatile("rdtsc \n\t" "mov %%edx, %0\n\t" "mov %%eax, %1 \n\t" :"=r"(high32), "=r"(low32)::"%rax","rbx","rcx","rdx");    
    unsigned long long generated= (((unsigned long long) high32 << 32| low32)) ;
    long seconds =(generated/(3.3*1000000000));
    int days = seconds %8647;
    int minutes = seconds %60;

    return (generated/(3.3*1000000000)); // dividing by processor frequency
}
void PrintE2(int signum)
{
    printf("Inside E2\n");
    union sigval value;
    //int a=4;
    value.sival_int = rdtsc();
    
    sigqueue(pid1,SIGTERM,value);
}
int main(int argc , char * argv[])
{
    // struct sigaction test;
    // test.sa_sigaction = PrintE1;
    // test.sa_flags= SA_SIGINFO;
    // //test.si_value;
    struct itimerval ST_Timer;
    ST_Timer.it_value.tv_sec  =    2;
    ST_Timer.it_value.tv_usec =    0;	
    ST_Timer.it_interval = ST_Timer.it_value;
    

    signal(SIGALRM,PrintE2);
    int y=setitimer(ITIMER_REAL, &ST_Timer, NULL);  
            
    // value.sival_ptr = (void*)a;
    pid1 = atoi(argv[1]);
    printf("%d\n",pid1);
    //PrintE1();
    while(1)
    {
        pause();
    }
    //kill(pid1, SIGTERM);
    
    
}
