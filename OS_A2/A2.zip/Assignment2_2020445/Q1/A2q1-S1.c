#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
//extern void PrintE1();
// struct itimerval {
//     struct timeval it_value; /* next value */
//     struct timeval it_value;    /* current value */
// };
void  S1_handler(int sig, siginfo_t *info, void *ucontext)
{
    printf("%d \n",info->si_value.sival_int);
}


// void  SR_Caller(pid_t pid)
// {
//     char * spid = malloc(6);   // ex. 34567
//     sprintf(spid, "%d", pid);
//     char * args[]={spid, NULL};
//     execv("./E1",args);
// }
// void SR_Handler(void)
// {
//     printf("Alarm triggered\n");
// }
// void ST_Caller()
// {

// }

int main(int argc , char * argv[])
{

    
    //test.si_value;
    // struct itimerval SR_Timer;
    // SR_Timer.it_value.tv_sec =     2000/1000;
    // SR_Timer.it_value.tv_usec =    (2000*1000) % 1000000;	
    // SR_Timer.it_interval = SR_Timer.it_value;
    
    pid_t pid1,pid2,pid3;
    int status;
    pid1 =fork();
    if (pid1==0)
    {   
        printf("S1 child\n");
           // printf("%d %d\n",getpid(),getppid());
        struct sigaction S1;
        S1.sa_sigaction = &S1_handler;
        S1.sa_flags= SA_SIGINFO;
        // waitpid(pid2,&status,0);
        // waitpid(pid3,&status,0);
        sigaction(SIGTERM, &S1,NULL);
        while(1);
        //pause();
    }
    else if(pid1>0)
    {
        //waitpid(pid1, &status, 0);
        pid2=fork();
        if(pid2==0)
        {
            printf("SR child\n");
           // printf("%d %d\n",getpid(),getppid());
           // printf("%d %d",pid2,pid1);
            char * spid = malloc(6);   // ex. 34567
            sprintf(spid, "%d", pid1);
            char * args[]={"./E1",spid, NULL};
            execv("./E1",args);             
            //SR_Caller(pid1);
        }
        else if(pid2>0)
        {
            //waitpid(pid2, &status, 0);
            printf("ST child\n");
            char * spid = malloc(6);   // ex. 34567
            sprintf(spid, "%d", pid1);
            char * args[]={"./E1",spid, NULL};
            execv("./E2",args);             
            
        }
    }
}