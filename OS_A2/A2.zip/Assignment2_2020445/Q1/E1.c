#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include<signal.h>
#include <sys/types.h>
#include<unistd.h>
# include <sys/time.h>
# include <stdint.h>
#include <stdlib.h>
pid_t pid1;

int rdrand ()
{
    int generated;
	asm volatile ("rdrand %0" :"=r" (generated)::);
	return generated;
}


void PrintE1(int signum)
{
    printf("Inside E1\n");
    union sigval value;
    int a=rdrand();
    value.sival_int = rdrand();
    sigqueue(pid1,SIGTERM,value);
}
int main(int argc , char * argv[])
{
    // struct sigaction test;
    // test.sa_sigaction = PrintE1;
    // test.sa_flags= SA_SIGINFO;
    // //test.si_value;
    struct itimerval SR_Timer;
    SR_Timer.it_value.tv_sec  =    2;
    SR_Timer.it_value.tv_usec =    0;	
    SR_Timer.it_interval = SR_Timer.it_value;
    

    signal(SIGALRM,PrintE1);
    int y=setitimer(ITIMER_REAL, &SR_Timer, NULL);  
            
    // value.sival_ptr = (void*)a;
    pid1 = atoi(argv[1]);
    printf("%d\n",pid1);
    //PrintE1();
    while(1)
    {
        pause();
    }
    //kill(pid1, SIGTERM);
    return 0;
    
}