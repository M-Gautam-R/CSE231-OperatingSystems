#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include<pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#define writer 450
#define reader 451

sem_t S;
sem_t E;
sem_t F;
//int RNG=0;
long buff;
//long 
void* produce(void* num)
{   while(1)
    {
        int RNG = *(int *) num;
        sem_wait(&E);
        sem_wait(&S);
        
        
        //this is generating the random numbers
        read(RNG,&buff,8);
        long result = buff;
        
        //result=rand();
       // printf("%s",buff);
        syscall(450,result); // enqueue
        sem_post(&S);
        sem_post(&F);
     
    }
        
    
}

void* consume(void* num)
{   
    while(1)
    {
        //long result = read(random,8, sizeof(long));
        sem_wait(&F);
        sem_wait(&S);       
        syscall(451);
        sem_post(&S);
        sem_post(&E);
    }
  
}
int main()
{
    int RNG = open("/dev/urandom",O_RDONLY);
    if(RNG<0)
        {
            perror("urandom could not be opened");
        }
    int a =9;
    sem_init(&S,0,1);
    sem_init(&E,0,10);
    sem_init(&F,0,0);
  
    pthread_t t1,t2;
    
    pthread_create(&t1, NULL,produce,(void *)&RNG);
    pthread_create(&t2, NULL,consume,(void *)&a);
     pthread_join(t1,NULL);
     pthread_join(t2,NULL);
   
    
    // pid_t pid1 =fork();
    // if(pid1 ==0)
    // {
    //     consume();
    // }
    // else
    // {
    //     produce();
    // }
    // syscall(450,6);
    // syscall(450,2);
    // syscall(450,7);
    // syscall(451);
    // syscall(451);
    // syscall(451);
    // syscall(451);
    // syscall(451);
    // syscall(451);
    
}


