In this Question , we define a global queue using an array implementation in sys.c inside the kernel folder , defining the enqueue and dequeue functions.
There is a function called createQueue which runs only once and serves to create the array for the queue using kmalloc of size 10.

The enqueue function adds any new elements to the end of the array while dequeue removes it from the start of the array and we shift each element in the array by 1 
towards the left to account for this. The writer and reader system calls are also defined in sys.c , the data structures being used are queues so far. The other data structures being used are
semaphores as they are internally represented as structs. 

Inside the test program, we use 2 processes called producer(p) and Consumer(C), the producer reads the /dev/urandom file to generate a random number of 8 bytes which it sends to the
queue by calling our defined writer syscall. Similiarly the consumer reads from the queues and dequeues it by calling the read system call. The semaphores used here are E,S,F 
where E denotes how many slots are empty in the queue which is set to 10 at the start in sem_init and F denotes how many slots in the queue are filled by the producer which is set to 0 at the start.
The semaphore S is a binary semaphore(mutex) which controls the access to the shared queue so that only one of producer or consumer can access at a time.

I am using 2 threads here to simulate 2 programs running concurrently as these 2 threads will also be running simultaneously and thus it is functionally the same.
