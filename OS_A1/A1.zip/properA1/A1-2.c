#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
int  marksA[26][6];
int counterA;
void *Avg_A(void *vargp)
{
    char str[10000];
    double total_avg;
    double * a=malloc(sizeof(double));

    int fd, sz;
    struct stat st;
    stat("student_record.csv",&st);
    int size = st.st_size;
    char *c = (char *) calloc( size, sizeof(char));
    fd= open("student_record.csv",O_RDONLY);
    int a1,a2,a3,a4,a5,a6=0;
    char * lines[27];
    int  studentID[26];
    int finalID[26];
    
    char *section[26];
    if (fd < 0) 
    { 
        perror("r1"); 
    }
    sz = read(fd, c, size);
    //printf("%s", c);
    char* value = strtok(c, "\n");
    //printf("%s\n",value);
    int i=0;
    while(value!=NULL)
    {
        value=strtok(NULL,"\n");
        lines[i]=value;
        //printf("%s\n",lines[i]);
        i++;
    }
    counterA=0;
    for(int i=0;i<26;i++)
    {
        value = strtok(lines[i],",");
        studentID[i]=atoi(value);
        value = strtok(NULL, ",");
        section[i]=value;
        //printf("%s",value);
        //printf("%d\n",strcmp(value,"A"));
        
        if(strcmp(value,"A")==0)
        {
            
            value = strtok(NULL, ",");
            marksA[counterA][0]= atoi(value);
            //printf("%d fsef",marks[counter][0]);
            
            value = strtok(NULL, ",");
            marksA[counterA][1]= atoi(value);
            //printf("%d fsef",marks[counter][1]);
            value = strtok(NULL, ",");
            marksA[counterA][2]= atoi(value);
            //printf("%d fsef",marks[counter][2]);
            value = strtok(NULL, ",");
            marksA[counterA][3]= atoi(value);
            //printf("%d fsef",marks[counter][3]);
            value = strtok(NULL, ",");
            marksA[counterA][4]= atoi(value);
            //printf("%d fsef",marks[counter][4]);
            
            value = strtok(NULL, ",");
            marksA[counterA][5]= atoi(value);
            //printf("%d fsef",marks[counter][5]);
            counterA++;
        }
    }
    close(fd);
    int counter2=0;
    for(int i=0;i<26;i++)
    {
        if(strcmp(section[i],"A")==0)
        {
            finalID[counter2]=studentID[i];
            counter2++;
        }
    }
    // for(int m=0;m<counter2;m++)
    // {
    //     printf("%d ", finalID[m]);
    // }
    for(int j=0;j<counterA;j++)
    {
        double total=0;
        for(int k=0;k<6;k++)
        {
            total=total+marksA[j][k];
        }
        total_avg+=total;
        total=total/6;
        snprintf(str, 10000, "the avg marks of student %d from section A is %f\n",finalID[j],total);
        size_t w = write(1, str, strlen(str));
          if(w<0)
        {
            perror("write failed");
        }
        //printf("the avg marks of student %d from section A is %d",finalID[j],total);
        //printf("\n");
    }
    *a = total_avg;
    return (void*) a;
}
int  marksB[26][6];
int counterB;
void *Avg_B(void *vargp)
{
    char str[10000];
     double total_avg;
    double * a=malloc(sizeof(double));
    int fd, sz;
    struct stat st;
    stat("student_record.csv",&st);
    int size = st.st_size;
    char *c = (char *) calloc( size, sizeof(char));
    fd= open("student_record.csv",O_RDONLY);
    int a1,a2,a3,a4,a5,a6=0;
    char * lines[27];
    int  studentID[26];
    int finalID[26];
    
    char *section[26];
    if (fd < 0) 
    { 
        perror("r1"); 
    }
    sz = read(fd, c, size);
    //printf("%s", c);
    char* value = strtok(c, "\n");
    //printf("%s\n",value);
    int i=0;
    while(value!=NULL)
    {
        value=strtok(NULL,"\n");
        lines[i]=value;
        //printf("%s\n",lines[i]);
        i++;
    }
    counterB=0;
    for(int i=0;i<26;i++)
    {
        value = strtok(lines[i],",");
        studentID[i]=atoi(value);
        value = strtok(NULL, ",");
        section[i]=value;
        //printf("%s",value);
        //printf("%d\n",strcmp(value,"A"));
        
        if(strcmp(value,"B")==0)
        {
            
            value = strtok(NULL, ",");
            marksB[counterB][0]= atoi(value);
            //printf("%d fsef",marks[counter][0]);
            
            value = strtok(NULL, ",");
            marksB[counterB][1]= atoi(value);
            //printf("%d fsef",marks[counter][1]);
            value = strtok(NULL, ",");
            marksB[counterB][2]= atoi(value);
            //printf("%d fsef",marks[counter][2]);
            value = strtok(NULL, ",");
            marksB[counterB][3]= atoi(value);
            //printf("%d fsef",marks[counter][3]);
            value = strtok(NULL, ",");
            marksB[counterB][4]= atoi(value);
            //printf("%d fsef",marks[counter][4]);
            
            value = strtok(NULL, ",");
            marksB[counterB][5]= atoi(value);
            //printf("%d fsef",marks[counter][5]);
            counterB++;
        }
    }
    close(fd);
    int counter2=0;
    for(int i=0;i<26;i++)
    {
        if(strcmp(section[i],"B")==0)
        {
            finalID[counter2]=studentID[i];
            counter2++;
        }
    }
    // for(int m=0;m<counter2;m++)
    // {
    //     printf("%d ", finalID[m]);
    // }
    for(int j=0;j<counterB;j++)
    {
        double total=0;
        for(int k=0;k<6;k++)
        {
            total=total+marksB[j][k];
        }
        total_avg+=total;
        total=total/6;
        
        snprintf(str, 10000, "the avg marks of student %d from section B is %f\n",finalID[j],total);
        size_t w = write(1, str, strlen(str));
          if(w<0)
        {
            perror("write failed");
        }
        //printf("the avg marks of student %d from section A is %d",finalID[j],total);
        //printf("\n");
    }
    *a = total_avg;
    return (void*) a;


}
int main()
{
    pthread_t thread1;
    pthread_t thread2;
    double* Aval;
    double* Bval;
    pthread_create(&thread1, NULL, Avg_A, NULL);
    if(thread1!=0)
    {
        perror("Thread fail");
    }
    pthread_join(thread1, (void**)&Aval);   
    pthread_create(&thread2, NULL, Avg_B, NULL);
    if(thread1!=0)
    {
        perror("Thread fail");
    }
    pthread_join(thread2, (void**)&Bval);
    double a1,a2,a3,a4,a5,a6=0;
    for(int i=0;i<counterA;i++)
    {
        a1+=marksA[i][0];
        a2+=marksA[i][1];
        a3+=marksA[i][2];
        a4+=marksA[i][3];
        a5+=marksA[i][4];
        a6+=marksA[i][5];
    }
    for(int i=0;i<counterB;i++)
    {
        a1+=marksB[i][0];
        a2+=marksB[i][1];
        a3+=marksB[i][2];
        a4+=marksB[i][3];
        a5+=marksB[i][4];
        a6+=marksB[i][5];
    }
    printf("average across both sections for A1 is %f\n",a1/26 );
    printf("average across both sections for A2 is %f\n",a2/26 );
    printf("average across both sections for A3 is %f\n",a3/26 );
    printf("average across both sections for A4 is %f\n",a4/26 );
    printf("average across both sections for A5 is %f\n",a5/26 );
    printf("average across both sections for A6 is %f\n",a6/26 );
  
    // value=strtok(c, ",");
    // printf("%s",value);    
}
        

