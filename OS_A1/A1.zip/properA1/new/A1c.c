#include <stdio.h>
#include<stdlib.h>
void A1c()
{
    printf("currently in C");
    exit(0);
}
