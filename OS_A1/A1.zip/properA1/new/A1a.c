#include <stdio.h>
extern void A1b(long long a);
int main(int argc, char *argv[]) 
{
    long long val;
    printf("Currently in A\n");
    scanf("%lld",&val);
	A1b(val);
}
