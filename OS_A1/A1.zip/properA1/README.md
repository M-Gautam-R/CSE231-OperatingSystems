The fork system creation calls program has fork(), write(),open(),read(),close() as system calls
All of these are appropriately handled for their errors using the return values of these functions as the check(usually if the return value <0 it means process failed)
The code works by parsing through the CSV file and assigning marks to the students of each sections seperately, there are 2 functions to handle this being AvgA and AvgB
Both the functions print what they are supposed to do on their own
inside main , the return value from fork() is checked, if it is 0 it means it is a child process and we continue execution however if it is not 0 we wait using waitpid, till the child process finishes indicated by the -1

The threads program has an array of global marks for each section so that we can calculate the avg of both the sections across assignments, the pthread_create is error handled by checking its return value , if it is 0 then it was successful else not.The actual functions remain the same by and large

The second question dealing with Assembly + C has 3 files with the integer to ASCII conversion in A1b.asm and we manipulate the stack frame using lea- load effective address , what this does is it gets the memory address of A1C which goes into r8, and we push r8 onto the stack , so now A1c is at the top and when we ret , we now go to A1c instead of A1a.

A small note about makefiles: the make command was tested on WSL for windows however the threads program is causing problems due to Linux not detecting it so the makefile does not work there , however it works perfectly fine on windows powershell on VSCode

the commands to run the threads program is : gcc A1-2.c , and then run ./a.out