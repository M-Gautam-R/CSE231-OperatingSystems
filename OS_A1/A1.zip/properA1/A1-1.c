#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sysexits.h>
extern int errno;
void Avg_A()
{
        char str[10000];
    int fd, sz;
    struct stat st;
    stat("student_record.csv",&st);
    int size = st.st_size;
    char *c = (char *) calloc( size, sizeof(char));
    fd= open("student_record.csv",O_RDONLY);
    int a1,a2,a3,a4,a5,a6=0;
    char * lines[27];
    int  studentID[26];
    int finalID[26];
    int  marks[26][6];
    char *section[26];
    if (fd < 0) 
    { 
        perror("r1"); 
    }
    sz = read(fd, c, size);
    //printf("%s", c);
    char* value = strtok(c, "\n");
    //printf("%s\n",value);
    int i=0;
    while(value!=NULL)
    {
        value=strtok(NULL,"\n");
        lines[i]=value;
        //printf("%s\n",lines[i]);
        i++;
    }
    int counter=0;
    for(int i=0;i<26;i++)
    {
        value = strtok(lines[i],",");
        studentID[i]=atoi(value);
        value = strtok(NULL, ",");
        section[i]=value;
        //printf("%s",value);
        //printf("%d\n",strcmp(value,"A"));
        
        if(strcmp(value,"A")==0)
        {
            
            value = strtok(NULL, ",");
            marks[counter][0]= atoi(value);
            //printf("%d fsef",marks[counter][0]);
            
            value = strtok(NULL, ",");
            marks[counter][1]= atoi(value);
            //printf("%d fsef",marks[counter][1]);
            value = strtok(NULL, ",");
            marks[counter][2]= atoi(value);
            //printf("%d fsef",marks[counter][2]);
            value = strtok(NULL, ",");
            marks[counter][3]= atoi(value);
            //printf("%d fsef",marks[counter][3]);
            value = strtok(NULL, ",");
            marks[counter][4]= atoi(value);
            //printf("%d fsef",marks[counter][4]);
            
            value = strtok(NULL, ",");
            marks[counter][5]= atoi(value);
            //printf("%d fsef",marks[counter][5]);
            counter++;
        }
    }
     if (close(fd) < 0)
    {
        perror("close failed");
        return;
    }
    int counter2=0;
    for(int i=0;i<26;i++)
    {
        if(strcmp(section[i],"A")==0)
        {
            finalID[counter2]=studentID[i];
            counter2++;
        }
    }
    // for(int m=0;m<counter2;m++)
    // {
    //     printf("%d ", finalID[m]);
    // }
    for(int j=0;j<counter;j++)
    {
        double total=0;
        for(int k=0;k<6;k++)
        {
            total=total+marks[j][k];
        }
        total=total/6;
        snprintf(str, 10000, "the avg marks of student %d from section A is %f\n",finalID[j],total);
        size_t w = write(1, str, strlen(str));
        if(w<0)
        {
            perror("write failed");
        }
        //printf("the avg marks of student %d from section A is %d",finalID[j],total);
        //printf("\n");
    }
}

void Avg_B()
{
    char str[10000];
    int fd, sz;
    struct stat st;
    stat("student_record.csv",&st);
    int size = st.st_size;
    char *c = (char *) calloc( size, sizeof(char));
    fd= open("student_record.csv",O_RDONLY);
    int a1,a2,a3,a4,a5,a6=0;
    char * lines[27];
    int  studentID[26];
    int finalID[26];
    int  marks[26][6];
    char *section[26];
    if (fd < 0) 
    { 
        perror("r1"); 
    }
    sz = read(fd, c, size);
    //printf("%s", c);
    char* value = strtok(c, "\n");
    //printf("%s\n",value);
    int i=0;
    while(value!=NULL)
    {
        value=strtok(NULL,"\n");
        lines[i]=value;
        //printf("%s\n",lines[i]);
        i++;
    }
    int counter=0;
    for(int i=0;i<26;i++)
    {
        value = strtok(lines[i],",");
        studentID[i]=atoi(value);
        value = strtok(NULL, ",");
        section[i]=value;
        //printf("%s",value);
        //printf("%d\n",strcmp(value,"A"));
        
        if(strcmp(value,"B")==0)
        {
            
            value = strtok(NULL, ",");
            marks[counter][0]= atoi(value);
            //printf("%d fsef",marks[counter][0]);
            
            value = strtok(NULL, ",");
            marks[counter][1]= atoi(value);
            //printf("%d fsef",marks[counter][1]);
            value = strtok(NULL, ",");
            marks[counter][2]= atoi(value);
            //printf("%d fsef",marks[counter][2]);
            value = strtok(NULL, ",");
            marks[counter][3]= atoi(value);
            //printf("%d fsef",marks[counter][3]);
            value = strtok(NULL, ",");
            marks[counter][4]= atoi(value);
            //printf("%d fsef",marks[counter][4]);
            
            value = strtok(NULL, ",");
            marks[counter][5]= atoi(value);
            //printf("%d fsef",marks[counter][5]);
            counter++;
        }
    }
    if (close(fd) < 0)
    {
        perror("close failed");
        return;
    }
    int counter2=0;
    for(int i=0;i<26;i++)
    {
        if(strcmp(section[i],"B")==0)
        {
            finalID[counter2]=studentID[i];
            counter2++;
        }
    }
    // for(int m=0;m<counter2;m++)
    // {
    //     printf("%d ", finalID[m]);
    // }
    for(int j=0;j<counter;j++)
    {
        double total=0;
        for(int k=0;k<6;k++)
        {
            total=total+marks[j][k];
        }
        total=total/6;
        snprintf(str, 10000, "the avg marks of student %d from section B is %f\n",finalID[j],total);
        size_t w = write(1, str, strlen(str));
        if(w<0)
        {
            perror("write failed");
        }
        //printf("the avg marks of student %d from section A is %d",finalID[j],total);
        //printf("\n");
    }
}
int main()
{
    pid_t id;
    int stat;
    if((id=fork())==0)
    {
        Avg_A();
        exit(0);
    }
    else if(id>0)
    {
      
        while (waitpid(id, &stat, 0) == -1)
        {
//             if (stat != EINTR)
//             {
//                 perror("waitpid");
//  //               return EX_SOFTWARE;
//             }
        }
        Avg_B();
    }
    else
    {
        perror("fork");
    }
    
    
    // value=strtok(c, ",");
    // printf("%s",value);    
}
        

