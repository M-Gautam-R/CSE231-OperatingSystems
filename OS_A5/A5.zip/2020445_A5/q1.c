#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>

sem_t philos;
sem_t forks[5];

void * eat(void * num)
{
    int sem = *(int *) num;
    while(1)
    {
        sem_wait(&forks[sem]);
        sem_wait(&forks[(sem+1)%5]);
        printf("\nThe philospher %d managed to get 2 forks to eat", sem);
        sleep(2);
        sem_post(&forks[(sem+1)%5]);
        sem_post(&forks[sem]);
        printf("\nThe philospher %d left their 2 forks", sem);
    }
    
}
void * eat1(void * num)
{
    int sem = *(int *) num;
    while(1)
    {
        sem_wait(&forks[(sem+1)%5]);
        sem_wait(&forks[sem]);
        printf("\nThe philospher %d managed to get 2 forks to eat", sem);
        sleep(2);
        sem_post(&forks[sem]);
        sem_post(&forks[(sem+1)%5]);
        //sem_post(&forks[sem]);
        printf("\nThe philospher %d left their 2 forks", sem);
    }
    
}


int main()
{
    //sem_init(&philos, 0, 4);// 
    for(int i=0;i<5;i++)
    {
        sem_init(&forks[i],0,1); // each fork shared across all objects
    }
    int numbers[5] ={0,1,2,3,4};
    pthread_t t1,t2,t3,t4,t5;
    pthread_t threads[5];
 
	    pthread_create(&t1,NULL,eat,(void *)&numbers[0]);
         pthread_create(&t2,NULL,eat,(void *)&numbers[1]);
         pthread_create(&t3,NULL,eat,(void *)&numbers[2]);
         pthread_create(&t4,NULL,eat,(void *)&numbers[3]);
         pthread_create(&t5,NULL,eat1,(void *)&numbers[4]);
    
        pthread_join(t1,NULL);
        pthread_join(t2,NULL);
        pthread_join(t3,NULL);
        pthread_join(t4,NULL);
        pthread_join(t5,NULL);
  
        
}