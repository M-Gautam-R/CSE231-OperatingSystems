Q1 - philosphers require 2 forks in order to eat, this has the potential to cause deadlock because there are 5 forks and 
5 philosphers but each one wants 2 of these forks. So we use semaphores to control access to these forks such that if the fork
is free only then can the philospher take it.

We create an array of semaphores of length 5 consisting of binary semaphores shared by all the threads in the process.
and these semaphores act as our forks which get locked and opened. Inside the main program we create 5 threads which represent our philosphers
We provide these threads the eat and eat1 functions which take care of the fork allocation.

The deadlock problem is caused by all the philosphers picking up either their left or right forks all at the same time which will
result in all the philosphers holding 1 fork each and not being able to pick up another since none of them are free

We solve this by changing the order of any one philospher so that he picks the fork that is going to be taken(the othe 4 pick their left ones and this one picks his right one) leaving the other one free which means
that another philospher can get their 2 forks thereby leaving at least one fork free at all times.  

We used semaphore.h and the functions sem_init which specifies whether the semaphore will be shared across threads of a process or between multiple processes.It can also set whether 
it is a counting semaphore or binary semaphore based on the value parameter we pass in. sem_wait is the function that is effectively locking the semaphore until sem_post is called on it
to free it up for other threads.


Q3: This problem is quite similair to Q1 with the additional modification being that a philospher now needs one bowl on top of 2 forks to eat. We simulate this situation using a counting semaphore
of size 4 which denotes the maximum no of bowls available on the table. When the eat function is called through the thread(philospher) it first assigns a bowl to the philospher using the sem_wait() function 
and thereafter the rest of the program is same as Q1 with respect to the forks , we finally call sem_post on the bowl semaphore to free a particular bowl. 

Q2 : Unlike the above 2 questions there can be no deadlock in here because each philospher now needs only 1 fork and a bowl to eat, there won't be a deadlock here because at a time 4 philosphers will be able to eat
and there cannot arise such a case where this will not be possible as there are 5 forks present and 4 bowls. for eg : if philospher 1 picks his left and philospher 3 picks his right then philospher 2 has both of his forks taken
but deadlock will not arise because philospher 4 and 5 can still pick up their forks. 

Resources referred: man pages for semaphores, GFG.