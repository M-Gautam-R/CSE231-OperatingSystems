#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>

sem_t bowls;
sem_t forks[5];
void * eat(void * num)
{
	int phil=*(int *)num;
    while(1)
    {
       
	sem_wait(&bowls);
     printf("\nPhilosopher %d has taken his bowl",phil);
    sleep(1);

	sem_wait(&forks[phil]);
	sem_wait(&forks[(phil+1)%5]);
    printf("\nPhilosopher %d has picked up his 2 forks",phil);
	//printf("\nPhilosopher %d has finished eating",phil);
	sleep(1);
	printf("\nPhilosopher %d has left his 2 forks",phil);

	sem_post(&forks[(phil+1)%5]);
	sem_post(&forks[phil]);
    
    printf("\nPhilosopher %d has left his bowl",phil);
	sem_post(&bowls);
    sleep(1);
    }
    
}
void * eat1(void * num)
{
	int phil=*(int *)num;
    while(1)
    {
    
	sem_wait(&bowls);
    printf("\nPhilosopher %d has taken his bowl",phil);
    sleep(1);
	
	
	sem_wait(&forks[(phil+1)%5]);
    sem_wait(&forks[phil]);
    printf("\nPhilosopher %d has picked up his 2 forks",phil);
	//printf("\nPhilosopher %d has finished eating",phil);
	sleep(1);
	
    printf("\nPhilosopher %d has left his 2 forks",phil);
	
	sem_post(&forks[phil]);
    sem_post(&forks[(phil+1)%5]);
    
    printf("\nPhilosopher %d has left his bowl",phil);
	sem_post(&bowls);
    sleep(1);
    }
}
int main()
{
	int a[5];

	 int numbers[5] ={0,1,2,3,4};
	//sem_init(&room,0,4);
	sem_init(&bowls,0,4);
	
    for(int i=0;i<5;i++)
		sem_init(&forks[i],0,1);

     pthread_t t1,t2,t3,t4,t5;
	 pthread_create(&t1,NULL,eat,(void *)&numbers[0]);
         pthread_create(&t2,NULL,eat,(void *)&numbers[1]);
         pthread_create(&t3,NULL,eat,(void *)&numbers[2]);
         pthread_create(&t4,NULL,eat,(void *)&numbers[3]);
         pthread_create(&t5,NULL,eat1,(void *)&numbers[4]);
    
        pthread_join(t1,NULL);
        pthread_join(t2,NULL);
        pthread_join(t3,NULL);
        pthread_join(t4,NULL);
        pthread_join(t5,NULL);
}



